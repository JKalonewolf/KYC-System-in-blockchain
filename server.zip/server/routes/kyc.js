const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const KYC = require('../models/KYC');
const User = require('../models/User');
const blockchainService = require('../services/blockchainService');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 🗂️ Setup multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = 'uploads/';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.jpg' && ext !== '.jpeg' && ext !== '.png') {
      return cb(new Error('Only .jpg, .jpeg, .png files allowed'));
    }
    cb(null, true);
  },
});

// 📥 Customer submits KYC request (with selfie upload)
router.post('/submit', authMiddleware, upload.single('selfie'), async (req, res) => {
  const {
    fullName,
    address,
    documentType,
    documentNumber,
    consentGiven,
    customerWalletAddress,
  } = req.body;

  try {
    if (!req.file) return res.status(400).json({ message: 'Selfie image is required' });

    if (!fullName || !address || !documentType || !documentNumber || !consentGiven || !customerWalletAddress) {
      return res.status(400).json({ message: 'All KYC fields are required' });
    }

    const existingKYC = await KYC.findOne({ user: req.user.userId });
    if (existingKYC) {
      return res.status(400).json({ message: 'KYC already submitted.' });
    }

    const selfieUrl = `/uploads/${req.file.filename}`;

    // ✅ Blockchain: submitKYC on-chain first
    const txHash = await blockchainService.submitKYC(customerWalletAddress);

    // ✅ Save in MongoDB
    const newKyc = new KYC({
      user: req.user.userId,
      fullName,
      address,
      documentType,
      documentNumber,
      selfieUrl,
      consentGiven,
      customerWalletAddress,
      status: 'Pending',
      blockchainTxHash: txHash,
    });

    await newKyc.save();

    res.status(201).json({
      message: 'KYC submitted and pushed to blockchain successfully',
      kyc: newKyc,
      txHash,
    });
  } catch (err) {
    console.error("❌ Error submitting KYC:", err);
    res.status(500).json({ message: 'Server error during KYC submission', error: err.message });
  }
});

// ✅ Bank approves or rejects KYC
router.put('/update/:id', authMiddleware, async (req, res) => {
  const { status } = req.body;

  try {
    if (req.user.role !== 'bank') {
      return res.status(403).json({ message: 'Access denied: Only banks can approve/reject' });
    }

    const kyc = await KYC.findById(req.params.id);
    if (!kyc) return res.status(404).json({ message: 'KYC request not found' });

    const walletAddress = kyc.customerWalletAddress;
    if (!walletAddress) return res.status(400).json({ message: 'Missing customer wallet address' });

    let txHash;

    if (status === 'Approved') {
      txHash = await blockchainService.approveKyc(walletAddress);
    } else if (status === 'Rejected') {
      txHash = await blockchainService.rejectKyc(walletAddress);
    } else {
      return res.status(400).json({ message: 'Invalid status. Use "Approved" or "Rejected"' });
    }

    kyc.status = status;
    kyc.blockchainTxHash = txHash;
    await kyc.save();

    console.log(`✅ KYC ${status} on-chain: ${txHash}`);

    res.status(200).json({
      message: `KYC ${status} and pushed to blockchain`,
      txHash,
    });

  } catch (err) {
    console.error("❌ Error updating KYC status:", err);
    res.status(500).json({ message: 'Server error during KYC update', error: err.message });
  }
});


// 📥 Fetch KYC from blockchain by wallet address
router.get("/get/:walletAddress", async (req, res) => {
  const { walletAddress } = req.params;

  try {
    const kycData = await blockchainService.getKycData(walletAddress);

    // Format smart contract tuple to JSON
    const formatted = {
      documentHash: kycData[0],
      status: parseInt(kycData[1]), // enum: 0=Pending, 1=Approved, 2=Rejected
      consentGiven: kycData[2]
    };

    res.status(200).json(formatted);
  } catch (error) {
    console.error("❌ Error in /api/kyc/get/:walletAddress", error);
    res.status(500).json({ message: "Failed to fetch KYC data from blockchain" });
  }
});

module.exports = router;
